import styles from './waterfall.module.css'
const Waterfall = (props) => {
    const {
        loading,
        fetchMore,
        images
    } = props
    return (
        <>
            <div className={styles.wrapper}>
                <div className={styles.column}> 
                    {
                        images.filter((_,i) => i % 2 === 0).map(
                            img => (
                                <img key={img.id} src={img.url} />
                            )
                        )
                    }
                </div>
                <div className={styles.column}>
                    {
                         images.filter((_,i) => i % 2 !== 0).map(
                            img => (
                                <img key={img.id} src={img.url} />
                            )
                        )
                    }
                </div>
            </div>
        </>
    )
}

export default Waterfall;