export default [
    {
      text: '浙江省',
      value: '330000',
      children: [
        {
          text: '杭州市',
          value: '330100',
        },
        {
          text: '宁波市',
          value: '330200',
        },
        {
          text: '温州市',
          value: '330300',
        },
      ],
    },
    {
      text: '江苏省',
      value: '320000',
      children: [
        {
          text: '南京市',
          value: '320100',
        },
        {
          text: '无锡市',
          value: '320200',
        },
        {
          text: '徐州市',
          value: '320300',
        },
      ],
    },
  ]