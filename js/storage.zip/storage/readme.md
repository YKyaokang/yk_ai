# Storage 存储

  - 前端存储
    - cookie
    存储啥玩意 
      - 登录状态
      - 购物车 
    - localStorage
    - sessionStorage
    - indexDB
  - 后端存储
    MYSQL NoSQL MongoDB  
  - 缓存
    
  端口 -> 某个服务
3306 mysql 服务 进程（资源） 线程（执行）->入栈
domain(localhost) -> ip 地址(127.0.0.1)
一个ip地址背后对应的是? 某台设备 -> port 设备上的某个服务（进程）
一台设备上可以很多端口使用，有多个http服务 
不要使用一些特殊的端口 


## 首页 
